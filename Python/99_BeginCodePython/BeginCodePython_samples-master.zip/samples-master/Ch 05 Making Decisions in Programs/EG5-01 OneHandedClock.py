# EG5-01 One handed clock Version 1.0

import time

current_time = time.localtime()

hour = current_time.tm_hour

print('The hour is', hour)
