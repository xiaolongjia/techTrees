# EG5-07 Uppercase Greeter

name = input('Enter your name: ')

if name.upper() == 'ROB':
    print('Hello, Oh great one')
