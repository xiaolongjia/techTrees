# EG5-12 Snaps get_string function

import snaps

name = snaps.get_string('Enter your name: ')
snaps.display_message('Hello ' + name)
