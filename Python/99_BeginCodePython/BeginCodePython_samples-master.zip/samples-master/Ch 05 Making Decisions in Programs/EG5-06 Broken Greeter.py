# EG5-06 Broken Greeter
name = input('Enter your name: ')
if name == 'Rob':
    print('Hello, Oh great one')
