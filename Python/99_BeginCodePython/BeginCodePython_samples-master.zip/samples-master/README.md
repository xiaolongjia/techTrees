# samples
Sample code for  Begin to Code with Python by Rob Miles

The samples are written for Python 3.6 and are keyed to the chapters in the book. You can order the book from Amazon. 
