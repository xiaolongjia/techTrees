# EG6-14 Code Analysis 3
for count in range(1,13):
    count=13
    print(count)
print('Finished')
