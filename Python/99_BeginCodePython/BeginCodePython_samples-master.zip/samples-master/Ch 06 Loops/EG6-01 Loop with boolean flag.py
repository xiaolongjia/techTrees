# EG6-01 Loop with boolean flag
flag=True
while flag:
    print('Inside loop')
    flag=False
print('Outside loop')
