# EG6-14 Code Analysis 3
while True:
    break;
print('Finished')
