# EG6-02 Loop with counter
count=0
while count<5:
    print('Inside loop')
    count=count+1
print('Outside loop')
