# EG6-12 Code Analysis 1
for count in range(1,13):
    if count==5:
        break
    print(count)
print('Finished')
