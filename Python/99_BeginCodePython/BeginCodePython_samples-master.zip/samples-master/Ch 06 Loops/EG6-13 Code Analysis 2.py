# EG6-13 Code Analysis 2
for count in range(1,13):
    if count==5:
        continue
    print(count)
print('Finished')
