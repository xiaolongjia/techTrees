# EG6-10 Name printer
names=('Rob','Mary','David','Jenny','Chris','Imogen')
for •name  in •names :
    print(name)
