# EG6-09 Times Table Tutor
count = 1
timesValue = 2
while count < 13:
    result = count * timesValue
    print(count,'times',timesValue,'equals',result)
    count = count + 1; 
