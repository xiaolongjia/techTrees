import time
print('I will need to think about that..')
time.sleep(5)
print('The answer is: 42')
