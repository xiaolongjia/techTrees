# EG3-04 hello world

import snaps

snaps.display_message('hello world')
