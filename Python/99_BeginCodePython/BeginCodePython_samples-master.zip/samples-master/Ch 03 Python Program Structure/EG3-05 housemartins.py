# EG3-05 housemartins

import snaps

snaps.display_image('Housemartins.jpg')
snaps.display_message('Hull Rocks',color=(255,255,255),vert='top')
