# EG3-03 Egg timer
import time
print('Put the egg in boiling water now')
time.sleep(300)
print('Take the egg out now')
