# EG3-06 Ding

import snaps

snaps.play_sound('ding.wav')
