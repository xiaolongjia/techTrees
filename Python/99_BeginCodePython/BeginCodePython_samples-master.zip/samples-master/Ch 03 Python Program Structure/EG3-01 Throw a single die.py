import random #import the random library
print(random.randint(1,6))
