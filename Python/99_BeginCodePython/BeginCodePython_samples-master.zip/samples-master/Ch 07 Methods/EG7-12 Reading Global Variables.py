# EG7-12 Reading Global Variables 

cheese=99

def func():
    print('Global cheese is:',cheese)

func()

