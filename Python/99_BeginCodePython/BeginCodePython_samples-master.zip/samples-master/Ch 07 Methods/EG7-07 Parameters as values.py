# EG7-07 Parameters as values
def what_would_I_do(input_value):
    input_value = 99

test=0
what_would_I_do(test)
print('The value of test is',test)
