# EG7-08 get_value investigation 1
def get_value(prompt, value_min, value_max):
    return 1
    return 2

ride_number=get_value(prompt='Please enter the ride number you want:',value_min=1,value_max=5)
print('You have selected ride:',ride_number)
