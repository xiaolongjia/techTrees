# EG4-04 Pizza Order Calculator

students_text = input('How many students: ')

students_int = int(students_text)

pizza_count = students_int/1.5

print('You will need', pizza_count, 'pizzas')

