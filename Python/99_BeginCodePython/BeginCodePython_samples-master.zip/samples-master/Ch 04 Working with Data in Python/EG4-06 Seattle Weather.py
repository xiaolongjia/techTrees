# EG4-06 Seattle Weather

import snaps

desc=snaps.get_weather_desciption(latitude=47.61, longitude=-122.33)
print('The conditions are:',desc)
