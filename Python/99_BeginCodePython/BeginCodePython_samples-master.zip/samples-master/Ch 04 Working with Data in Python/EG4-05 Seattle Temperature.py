# EG4-05 Seattle Temperature 

import snaps

temp = snaps.get_weather_temp(latitude=47.61, longitude=-122.33)
print('The temperature in Seattle is:', temp)
