'''
Classes to implement a Graphical User Interface vesrion
of the Fashion Shop application
'''
