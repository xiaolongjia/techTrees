# EG8-24 Day Name List

day_number=1

day_names=['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday']

day_name=day_names[day_number]

print(day_name)
