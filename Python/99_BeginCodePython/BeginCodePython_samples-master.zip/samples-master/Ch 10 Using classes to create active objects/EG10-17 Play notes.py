# EG10-17 Play notes
import time
import snaps

for note in range(0,13):
    snaps.play_note(note)
    time.sleep(.5)
