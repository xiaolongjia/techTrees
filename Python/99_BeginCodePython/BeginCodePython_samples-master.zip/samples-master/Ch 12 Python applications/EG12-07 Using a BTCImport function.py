# EG12-07 Using a BTCImport function

import BTCInput

age = BTCInput.read_int_ranged(prompt='Enter age: ', min_value=5, max_value=95)
print('Your age is: ',age) 
