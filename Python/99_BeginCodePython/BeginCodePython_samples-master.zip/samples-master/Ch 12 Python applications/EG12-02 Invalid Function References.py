# EG12-02 Invalid Function References

def func_1(): 
    print('hello from function 1')

x = func_1 
x(99) 
