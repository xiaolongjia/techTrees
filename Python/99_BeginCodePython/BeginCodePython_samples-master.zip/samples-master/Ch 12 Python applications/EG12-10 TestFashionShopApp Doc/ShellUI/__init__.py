'''
Classes to implement a Python Command Shell vesrion
of the Fashion Shop application
'''
