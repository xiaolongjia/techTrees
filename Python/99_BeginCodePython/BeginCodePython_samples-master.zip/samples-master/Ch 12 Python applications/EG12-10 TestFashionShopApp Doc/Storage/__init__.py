'''
Data storage classes for the Fshion Shop application
'''
