# online_intepreter_project
online python intepreter using django restful api 

Please refer dev.py in online_intepreter_project/setting/ to create local.py, 
and change 
1. local database setting.
2. SECRET_KEY variable 
