
def ISBN():
    dig1 = int(input())
    dig2 = int(input())
    dig3 = int(input())
    sum = 91 + dig1*1 + dig2*3 + dig3*1
    print('The 1-3-sum is', sum)


ISBN()

