
def age_sib():
    sib_1 = int(input())
    sib_2 = int(input())
    print(sib_2-sib_1+sib_2)


age_sib()
