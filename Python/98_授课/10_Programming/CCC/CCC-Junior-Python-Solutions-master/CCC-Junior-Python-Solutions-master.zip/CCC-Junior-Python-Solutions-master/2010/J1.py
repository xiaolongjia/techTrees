
number = input()

n = int(number)

if n==1 or n==10 or n==9:
    print('1')
elif n==2 or n==3 or n==8 or n==7:
    print('2')
elif n==4 or n==5 or n==6:
    print('3')
