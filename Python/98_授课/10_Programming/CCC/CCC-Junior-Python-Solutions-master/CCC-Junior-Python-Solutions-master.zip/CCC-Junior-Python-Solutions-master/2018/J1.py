
fourth = input()
third = input()
second = input()
last = input()

if (fourth=='8' or fourth =='9') and third==second and (last=='8' or last=='9'):
  print('ignore')
else:
  print('answer')
  
