# Contest-Solutions
To prepare for the USACC and the CCC, I try to do contest questions on a daily basis. Every once in a while, I update some of my saved code onto here to give a representation of my abilities.
All the solutions put on here have 100% on DMOJ, but I might have forgot to submit the code every now and then so let me know if there are any problems!
